velocidade_maxima = 80
velocidade_carro = 85 

maximo= velocidade_maxima >velocidade_carro 

print (maximo)

