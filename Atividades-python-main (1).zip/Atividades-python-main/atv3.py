s1 = "Python"
s2 = "pythonn"

print(s1==s2)