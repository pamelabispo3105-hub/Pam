# liçao 4
numero = [1,2,3,4,5,6,7,8,9,10]
tabuada=5

# Para cada item dentro da minha lista 
for i in numero:
    # print(numero)
    print(i*tabuada)
    # print ( f"{numero}" x {1} = {numero * in}") 
           
           
           
           