# Exercício 1 lição

Número = float (input( "Digite um Número:"))

if Número > 0:
     print ("Positivo")