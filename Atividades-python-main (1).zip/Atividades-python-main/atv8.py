Frutas = ['maçã ', 'banana' , 'laranja',]

for fruta in frutas:
    print (frutas)
