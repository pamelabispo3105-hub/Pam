# Exercício 5 Lição

senha = input ("Digitye a senha: ")

if senha == "!234":
    print ("Acesso permitido")
else:
    print ("Acesso negado")