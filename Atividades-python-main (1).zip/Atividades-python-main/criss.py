numero =5

for item in range (11):
    print (f' {item}x{numero}= {item * numero}')
        