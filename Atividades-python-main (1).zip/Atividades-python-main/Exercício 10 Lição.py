# Exercício 10 Lição

numero = int (input ("Digite um numero de 1 a 7:")

if numero == 1:
    print("Domingo")
elif numero == 2:
    print("segunda-feira")
elif numero == 3:
    print ("Terça- feira")
elif numero == 4:
    print ("Quarta-feira")
elif numero == 5:
    print ("Quinta-feira")
elif numero == 6:
    print ("Sexta-feira")
elif numero == 7:
    print ('Sábado')
elif numero == 8:
else:
    print ("Número inválido ! Digite de 1 a 7.")