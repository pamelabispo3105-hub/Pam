# Exercício 6 Lição

idade = int (input("Digite a idade: "))

if 0 <= idade <= 12: 
    print("Crinça")
elif 13 <= idade <= 17:
    print('ola')
    print("Adolescente")   
else:
   print ("voce é adulto")