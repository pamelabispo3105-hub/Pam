palavra= 'joao' 

for item in palavra:
    print(item)
    # SE ,3


    if item in 'aeiou':
        print('é vogal')
    else:
        print('não é vogal')








# numeros = [1,2,3,4,5]

# soma = 0 

# for num in numeros:
#     soma += num 

# print("soma dos elementos:", soma)





frutas = ['maçã' , 'banana' , 'laranja']
          
for fruta in frutas:
    print (fruta)
          