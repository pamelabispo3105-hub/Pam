    
a= int (input("Digite o valor para variável A:"))
b= int (input("Digite o valor para variável"))

 #Exibe os resultados das comparações
print("Comparações")
print("a > b", a >b ) 
print("a < b=", a < b )
print("a != b =", a != b )
print("a == b =", a == b )