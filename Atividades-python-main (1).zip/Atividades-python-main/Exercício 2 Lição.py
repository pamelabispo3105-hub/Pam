# Exercício 2 - verfixcar se um número é pare ou impar

número = int(input("Digite um número"))

if número % 2 == 0:
    print ("Par")
else:
    print ("Limpar")